function calculate_time(data,client){
  var eventCallback = function (event) {
    var ParsedTimerToggleData = event.helper.getData();
    var id_string = ParsedTimerToggleData.id.toString();
    client.db.get(ParsedTimerToggleData.ticket_id).then (
      function(data) {
        data[id_string] = ParsedTimerToggleData.time_spent;
        client.db.set( ParsedTimerToggleData.ticket_id, data);
      },
      function(error) {
        if(error.status == 404){
          var setData = {};
          setData[id_string] = ParsedTimerToggleData.time_spent;
          client.db.set( ParsedTimerToggleData.ticket_id, setData);
        }
      });

  };
  client.events.on("ticket.stopTimer", eventCallback);
}

function alert_agent(client,data,iparams){
  var companyUrl = "https://"+iparams.subdomain+".freshdesk.com/api/v2/companies/"+data.company.id;
  var companyOptions = {
    headers: {
      'Content-Type' : 'application/json',
      'Authorization': '<%=  encode(iparam.apikey) %>'
    }
  };
  client.request.get(companyUrl,companyOptions)
  .then(function(companyData){
    var parsedCompanyData = JSON.parse(companyData.response);
    var split_hr_min = parsedCompanyData.custom_fields.contract_time.split(".");
    var in_mins = Math.round(60*(split_hr_min[1]/100));
    if(parseInt(parsedCompanyData.custom_fields.contract_time) < parseInt(iparams.alertAgentHours)){
      $("#alerttext").text("Remaining contract hours : " + split_hr_min[0] + " hours and " + (in_mins ? in_mins : "00") +" minutes");
    }
    else
    {
      $("#alerttextgreen").text("Remaining contract hours : " + split_hr_min[0] + " hours and " + (in_mins ? in_mins : "00") +" minutes");
    }
  },
  function(error){
    $('#apptext').text("Error in fetching company data [agent] - " + error.response);
  });
}


function minus_remaining_hours (client,ticketData,iparams,companyapiData, companyData){
  client.db.get(ticketData.ticket.id).then (
  function(data) {
    var updateData = [];
    updateData[0] = 0;
    updateData[1] = 0;
    $.each(data, function(key, value){
      if(value > 59){
        var mins = value/60;
        if(mins > 59){
          var hrs = mins/60;
          var mins = mins % 60;
          updateData[0] += hrs; 
          updateData[1] += mins;
        }else{
          updateData[0] += 0;
          updateData[1] += mins;
        }
      }
    });
    var time_spent_data = updateData[0] + parseInt(updateData[1])/60;
    var remaining_hours = parseFloat(JSON.parse(companyapiData.response).custom_fields.contract_time).toFixed(2) - time_spent_data;
    var fixed_two_time = remaining_hours.toFixed(2);
    var companyupdateURL = "https://"+iparams.subdomain+".freshdesk.com/api/v2/companies/"+companyData.company.id ;
    var companyUpdateOptions = {
      headers: {
        'Content-Type' : 'application/json',
        'Authorization': '<%=  encode(iparam.apikey) %>'
      },
      body: JSON.stringify({custom_fields :{contract_time : fixed_two_time.toString() }})
    };
    client.request.put(companyupdateURL, companyUpdateOptions)
    .then(function(){
      client.db.delete(ticketData.ticket.id);
      client.interface.trigger("showNotify", {type: "success", message: "Updated contract hours for " + companyData.company.name});
      $('#appupdate').text("Contract time has been updated! please refresh the page to see the updated time.");
    },function(updatecompanyErr){
      $('#apptext').text("Error in updating company data - " + updatecompanyErr.response);
    });
  },function(error){
    $('#apptext').text("Internal app error! Please reload the app - " + error.message);
  });
}

function statuschange(client){
  var propertyChangeCallback = function (event){
    var event_data = event.helper.getData();
    if(event_data.new == 5)
    {
      client.data.get("company")
      .then(function(companyData){
        client.iparams.get()
        .then(function(iparams){
          client.data.get("ticket")
          .then(function(ticketData){
            var timerOptions = {
              headers: {
                'Content-Type' : 'application/json',
                'Authorization': '<%=  encode(iparam.apikey) %>'
              }
            };
            var companyURL = "https://"+iparams.subdomain+".freshdesk.com/api/v2/companies/"+companyData.company.id ;
            client.request.get(companyURL, timerOptions )
            .then(function(companyapiData){
             minus_remaining_hours (client,ticketData,iparams,companyapiData, companyData);
           },function(companyapiErr){
            $('#apptext').text("Error in fetching company data - " + companyapiErr.response);
          });
          },function(ticketDataErr){
            $('#apptext').text("Error in fetching ticket data - " + ticketDataErr.message);
          });

        },function(iparamserror){
          $('#apptext').text("Error in fetching iparams - " + iparamserror.message);
        });
      }, function(companyErr){
        $('#apptext').text("Error in fetching company data - " + companyErr.message);
      });
    }
  };
  client.events.on("ticket.statusChanged", propertyChangeCallback);
}

$(document).ready( function() {
  app.initialized()
  .then(function(_client) {
    var client = _client;
    client.events.on('app.activated',
      function() {
        $("#apptext").empty();
        $("#alerttext").empty();
        $("#alerttextgreen").empty();
        $("#appupdate").empty();
        client.data.get("company").then (
          function(data) {
            if(!$.isEmptyObject(data.company))
            {
              client.iparams.get()
              .then(function(iparams){
                var company_string = data.company.id.toString();
                if(iparams.companies.includes(company_string))
                {
                  alert_agent(client,data,iparams);
                  calculate_time(data,client);
                }else{
                  $('#apptext').text("Company not present under contract");
                }
              },
              function(iparamserror){
                $('#apptext').text("Error in fetching iparams - " + iparamserror.message);
              });
            }else{
              $('#apptext').text("Company not linked to the contact");
            }
          },
          function(error) {
            $('#apptext').text("Error in fetching company data - " + error.message);
          });
      });
    client.data.get("company").then (
      function(data) {
        calculate_time(data,client);
      },function(error){
        $('#apptext').text("Error in fetching company data - " + error.message);
      });
    statuschange(client);
  });
});
